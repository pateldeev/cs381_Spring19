#include <Engine.h>
#include <Mgr.h>

Mgr::Mgr(Engine *engine) {
	this->engine = engine;

}

Mgr::~Mgr() {
}

void Mgr::Init() {

}

void Mgr::LoadLevel() {

}

void Mgr::Stop() {

}

void Mgr::Tick(float dt) {

}
