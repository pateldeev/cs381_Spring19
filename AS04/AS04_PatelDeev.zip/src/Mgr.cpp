#include "Mgr.h"

Mgr::Mgr(Engine *engine) :
	m_engine(engine) {
}

Mgr::~Mgr(void) {

}
