#include "Aspect.h"

Aspect::~Aspect(void) {
}

Aspect::Aspect(Entity381 *parent) :
	m_parent_entity(parent) {
}

