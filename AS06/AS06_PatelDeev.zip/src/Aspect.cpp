#include <Aspect.h>
#include <Entity381.h>  //Aspect includes Entity381.h

Aspect::Aspect(Entity381 *ent) {
	entity = ent;
}

Aspect::~Aspect() {

}

void Aspect::Tick(float dt) {

}
