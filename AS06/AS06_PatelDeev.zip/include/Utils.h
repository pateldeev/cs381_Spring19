#ifndef UTILS_H_
#define UTILS_H_

float FixAngle(float angle);
float Clamp(float min, float max, float val);

#endif /* UTILS_H_ */
