#ifndef __TYPES381_h_
#define __TYPES381_h_

enum EntityTypes {
	DDG51Type, CarrierType, SpeedBoatType, FrigateType, AlienType, BansheeType
};

#endif // #ifndef __TYPES381_h_
